<div id="footer">
	<div id="footerText">
		<div id="footerLeft">
			<div id="footerTitle">SaungSaji.com</div>
			<div id="footerMenu">
				<div class="footerMenuLft"><a href="<?=$base?>/index.php/home/about" class="fancybox">Tentang kami</a></div>
				<div class="footerMenuRght"><a href="<?=$base?>/index.php/home/carapesan" class="fancybox">Cara pesan</a></div>	
				<div class="footerMenuRght"><a href="<?=$base?>/index.php/home/infopoin" class="fancybox">Info Poin</a></div>	
				<div class="footerMenuBdr">&nbsp;</div>
				<div class="footerMenuLft"><a href="<?=$base?>/index.php/home/contact" class="fancybox" id="contact_us" >Hubungi kami</a></div>
				<div class="footerMenuRght"><a href="<?=$base?>/index.php/home/carabayar" class="fancybox">Cara bayar</a></div>
				<div class="footerMenuBdr">&nbsp;</div>
				<div class="footerMenuLft"><a href="<?=$base?>/index.php/home/faq" class="fancybox">Pertanyaan sering</a></div>
				<div class="footerMenuRght"><a href="<?=$base?>/index.php/home/terms" class="fancybox">Aturan layanan</a></div>
			</div>
		</div>
		<div id="footerRight"><img src="<?=$base?>/img/twitter.jpg"> &nbsp;<img src="<?=$base?>/img/fb.jpg"></div>
		<div id="footerCopyrght">Copyright saungsaji&copy;2015 all rights reserved.</div>
	</div>
</div>
</body>
</html>